import os
import pandas as pd
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import GRU, Dense

print("-------------------------------------------------")
print("Initiating the upload of the CSV data...")
# Path to the folder containing the training data
folder = 'training_data/sub01'

# List to store DataFrames from each CSV file
dataframes = []

# Get the list of CSV files in the folder
csv_files = [file for file in os.listdir(folder) if file.endswith('.csv')]

# Function to convert non-numeric values to 0
def convert_to_integer(value):
    try:
        return int(value)
    except ValueError:
        return 0

# Read each CSV file, apply the conversion, and add it to the list of DataFrames
for file in csv_files:
    full_path = os.path.join(folder, file)
    df = pd.read_csv(full_path, header=None)  # Files have no headers

    for col in df.columns:
        df[col] = df[col].map(convert_to_integer)

    dataframes.append(df)

# Concatenate the DataFrames into one
data = pd.concat(dataframes, ignore_index=True)

# Separate features (columns 1-3) from labels (column 4)
x = data.iloc[:, 1:4].values
y = data.iloc[:, 4].values
# Split the data into training (90%) and test (10%) sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.10, random_state=42)
print("Data upload completed successfully.")
print("-------------------------------------------------")

# Normalize the data before feeding it to the neural network
scaler = StandardScaler()
x_train = scaler.fit_transform(x_train)
x_test = scaler.transform(x_test)


# Reshape to match the GRU input (number of samples, time steps, features)
x_train_reshaped = np.reshape(x_train, (x_train.shape[0], 1, x_train.shape[1]))
x_test_reshaped = np.reshape(x_test, (x_test.shape[0], 1, x_test.shape[1]))

# Create the GRU model with 8 layers and 32 cells on each layer
model = Sequential()
model.add(GRU(units=32, return_sequences=True, input_shape=(x_train_reshaped.shape[1], x_train_reshaped.shape[2])))
model.add(GRU(units=32, return_sequences=True))
model.add(GRU(units=32, return_sequences=True))
model.add(GRU(units=32, return_sequences=True))
model.add(GRU(units=32, return_sequences=True))
model.add(GRU(units=32, return_sequences=True))
model.add(GRU(units=32, return_sequences=True))
model.add(GRU(units=32))
model.add(Dense(units=1, activation='linear'))

# Build the model
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), loss='mean_squared_error', metrics=['accuracy'])
#model.compile(optimizer=tf.keras.optimizers.Adadelta(learning_rate=1.0), loss='mean_squared_error', metrics=['accuracy'])

print("Starting training...")
# Train the model and collect the story information
history = model.fit(x_train_reshaped, y_train, epochs=11, batch_size=32, validation_data=(x_test_reshaped, y_test))

# Save the trained model
print("Model saved successfully.")
model.save('modelo_gru-1_11epochs_scalerdata_adam_8layer_32cell.keras') # Optimal quantity

# Evaluate the model
loss = model.evaluate(x_test_reshaped, y_test)

# Visualize loss and accuracy across the epochs
plt.figure(figsize=(12, 6))

# Loss plot
plt.subplot(1, 2, 1)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Loss during training')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

# Precision plot
plt.subplot(1, 2, 2)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Precision during training')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

plt.tight_layout()
plt.show()





