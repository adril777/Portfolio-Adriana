import pandas as pd
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

# Load the previously trained model
loaded_model = tf.keras.models.load_model('model_gru-1_11epochs_scalerdata_adam_8layer_32cell.keras')

# Load new data from a CSV file
test_data = pd.read_csv('new_data.csv', header=None)  # Make sure the data has the same structure

# Separate the features of the new data (columns 1-3)
x = test_data.iloc[:, 1:4].values

# Normalize the new data
scaler = StandardScaler()
x_test = scaler.fit_transform(x)

x_test_reshaped = np.reshape(x_test, (x_test.shape[0], 1, x_test.shape[1]))

# Make predictions on the new data
predictions = loaded_model.predict(x_test_reshaped)

# Print the predictions
print("Predictions:")
for prediction in predictions:
    print(prediction[0])
